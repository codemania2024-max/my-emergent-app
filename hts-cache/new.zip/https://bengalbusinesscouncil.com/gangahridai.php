<!Doctype html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Bengal Business Council : The voice of bengali businesses worldwide</title>
    
    <meta name="robots" content="noindex">

    
    <link href="https://fonts.googleapis.com/css2?family=Work+Sans:wght@100;300;400;500;600;700;800&amp;display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display+SC:wght@400;700;900&amp;display=swap" rel="stylesheet">
    <link href="pro.min.css" rel="stylesheet"> 

    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="css/styles.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" type="text/css" href="css/jquery.fancybox.min.css">
    <link rel="stylesheet" href="../../assets/vendor/aos/dist/aos.css">
</head>

<style>
    .container-img {
        width: 100%;
        overflow: auto;
        position: relative;
    }

    .container-img img {
        display: block;
        max-width: none;
        width: auto;
        height: auto;
    }

        

        /* .handicraft-fair {
            For Local

            width: 550px;
            height: 40px;
            top: 1295px;
            left: 520px;

            For Online
            width: 90%;
            height: 100%;
            top: -138px;
            left: -37px;

            clip-path: polygon(
                2% 16%,     
                97% 2%,  
                96% 155%, 
                0% 106%   
            );


            background-color: rgba(255, 0, 0, 1);
            transition: 0.3s ease;
        } */


        @media (max-width: 767px) {
            .link-area.trade_fair {
                position: absolute;

                /* For Online */
                 top: 593px;
                left: 163px;
                width: 358px;
                height: 169px; 

                /* For Local */

                /*top: 1366px;*/
                /*left: 383px;*/
                /*width: 809px;*/
                /*height: 390px;*/

                /* background: rgba(255, 215, 0, 0.25);*/
                /*border: 2px solid rgba(255, 215, 0, 0.7);*/
                /*box-shadow: 0 0 15px rgba(255, 215, 0, 0.8); */
                border-radius: 8px;
                cursor: pointer;
                transition: all 0.3s ease-in-out;
                transform: rotate(5deg) skewX(-1deg);
                transform-origin: center;
            }

            /* Hover effect */
            .link-area.trade_fair:hover {
                background: rgba(255, 215, 0, 0.45);
                border-color: #FFD700;
                box-shadow: 0 0 30px 10px rgba(255, 215, 0, 0.9);
                transform: rotate(5deg) skewX(-1deg) scale(1.03);
            }

            /* === FOOD FAIR Polygon Area === */

            /* Common hover area styling */
            .hover-area {
                position: absolute;
                display: block;
                cursor: pointer;
                z-index: 10;
            }
            .hover-area-corporate {
                position: absolute;
                display: block;
                cursor: pointer;
                z-index: 10;
            }

            /* Food Fair */
        
            .food-fair {
                /* For Local */

                /*width: 1312px;*/
                /*height: 100%;*/
                /*top: -166px;*/
                /*left: -51px;*/

                /* For Online */
                 width: 625px;
                height: 100%;
                top: -69px;
                left: -51px; 

                /* 🔺 Clip to polygon shape */
                clip-path: polygon(
                    27% 27.9%, 
                    70% 28.5%, 
                    70% 54.1%, 
                    27% 54.2% 
                );

                 /*background-color: rgba(255, 215, 0, 0.5); */
                transition: 0.3s ease;
            }

            /* Hover effect */
            .food-fair:hover {
                background-color: rgba(255, 215, 0, 0.5);
                box-shadow: 0 0 20px 8px rgba(255, 215, 0, 0.6);
            }

            /* Handicraft Zone */

            .handicraft-fair {
                /* For local */
                /*top: 1323px;*/
                /*left: 522px;*/
                /*width: 547px;*/
                /*height: 43px;*/

                /* For Online */
                 top: 574px;
                left: 224px;
                width: 242px;
                height: 21px; 


                /* background: rgba(255, 215, 0, 0.25);*/
                /*border: 2px solid rgba(255, 215, 0, 0.7);*/
                /*box-shadow: 0 0 15px rgba(255, 215, 0, 0.8); */
                border-radius: 8px;
                cursor: pointer;
                transition: all 0.3s ease-in-out;
                transform: rotate(5deg) skewX(-1deg);
                transform-origin: center;
            }

            
            .hover-area-handicraft.handicraft-fair:hover {
                background: rgba(255, 215, 0, 0.45);
                border-color: #FFD700;
                box-shadow: 0 0 30px 10px rgba(255, 215, 0, 0.9);
                transform: rotate(5deg) skewX(-1deg) scale(1.03);
            }

            /* Corporate Fair */
            .corporate-fair {
                /* For Local */
                /*width: 1512px;*/
                /*height: 102%;*/
                /*top: 584px;*/
                /*left: 148px;*/

                /* For Onilne */
                /* width: 100%;
                height: 100%;
                top: 520px;
                left: 60px; */

                /* For Online */
                 width: 617px;
                height: 1252px;
                top: 235px;
                left: 93px; 

                /* 🔺 Clip to polygon shape */
                clip-path: polygon(
                    27% 41.6%, 
                    67.4% 43.5%, 
                    70.2% 30%, 
                    80% 30.5%, 
                    91.5% 54.1%, 
                    27% 54.2% 
                );

                 /*background-color: rgba(255, 215, 0, 0.2); */
                transition: 0.3s ease;
            }

            /* Hover effect */
            .corporate-fair:hover {
                background-color: rgba(255, 215, 0, 0.5);
                box-shadow: 0 0 20px 8px rgba(255, 215, 0, 0.6);
            }

            .hover-area-handicraft {
                position: absolute;
                display: block;
                cursor: pointer;
                z-index: 10;
            }
        }

        @media (min-width: 768px) {
            /* Trade Fair */
            .link-area.trade_fair {
                position: absolute;

                /* For Online */
                position: absolute;
                top: 1192px;
                left: 341px;
                width: 683px;
                height: 332px;

                /* For Local */

                /* position: absolute;
                top: 1369px;
                left: 395px;
                width: 785px;
                height: 379px; */

                /* background: rgba(255, 215, 0, 0.25);
                border: 2px solid rgba(255, 215, 0, 0.7);
                box-shadow: 0 0 15px rgba(255, 215, 0, 0.8); */
                border-radius: 8px;
                cursor: pointer;
                transition: all 0.3s ease-in-out;
                transform: rotate(5deg) skewX(-1deg);
                transform-origin: center;
            }

            /* Hover effect */
            .link-area.trade_fair:hover {
                background: rgba(255, 215, 0, 0.45);
                border-color: #FFD700;
                box-shadow: 0 0 30px 10px rgba(255, 215, 0, 0.9);
                transform: rotate(5deg) skewX(-1deg) scale(1.03);
            }

            /* === FOOD FAIR Polygon Area === */

            /* Common hover area styling */
            .hover-area {
                position: absolute;
                display: block;
                cursor: pointer;
                z-index: 10;
            }
            .hover-area-corporate {
                position: absolute;
                display: block;
                cursor: pointer;
                z-index: 10;
            }

        
            .food-fair {
                /* For Local */

                /* width: 90%;
                height: 100%;
                top: -165px;
                left: -63px;
                clip-path: polygon(33% 27.9%, 80.5% 28.5%, 79.5% 54.1%, 36% 54.2%); */
                /* background-color: rgba(255, 215, 0, 0.2); */
                /* transition: 0.3s 
                ease; */

                /* For Online */
                width: 83%;
                height: 100%;
                top: -138px;
                left: -108px;
                clip-path: polygon(33% 27.9%, 80.5% 28.5%, 79.5% 54.1%, 36% 54.2%);
                /* background-color: rgba(255, 215, 0, 0.2); */
                transition: 0.3s 
                ease;
            }

            /* Hover effect */
            .food-fair:hover {
                background-color: rgba(255, 215, 0, 0.5);
                box-shadow: 0 0 20px 8px rgba(255, 215, 0, 0.6);
            }

            /* Handicraft Zone */

            .handicraft-fair {
                /* top: 1321px;
                left: 522px;
                width: 548px;
                height: 39px; */

                /* For Online */
                top: 1153px;
                left: 451px;
                width: 480px;
                height: 36px;


                /* /* background: rgba(255, 215, 0, 0.25); */
                /* border: 2px solid rgba(255, 215, 0, 0.7);
                box-shadow: 0 0 15px rgba(255, 215, 0, 0.8); */ */
                border-radius: 8px;
                cursor: pointer;
                transition: all 0.3s ease-in-out;
                transform: rotate(5deg) skewX(-1deg);
                transform-origin: center;
            }

            
            .hover-area-handicraft.handicraft-fair:hover {
                background: rgba(255, 215, 0, 0.45);
                border-color: #FFD700;
                box-shadow: 0 0 30px 10px rgba(255, 215, 0, 0.9);
                transform: rotate(5deg) skewX(-1deg) scale(1.03);
            }

            /* Corporate fair */
            .corporate-fair {
                /* For Local */
                /* width: 100%;
                height: 100%;
                top: 600px;
                left: 270px; */

                /* For Online */
                width: 100%;
                height: 107%;
                top: 446px;
                left: 175px;


                clip-path: polygon(27% 41.6%, /* point 1 (x%, y%) */ 67.4% 43.5%, /* point 2 */ 70.2% 30%, /* right-middle */ 80% 30.5%, /* bottom-right */ 91.5% 54.1%, /* point 3 */ 27% 54.2% /* point 4 */);
                /* background-color: rgba(255, 215, 0, 0.2); */
                transition: 0.3s 
                ease;
            }

            /* Hover effect */
            .corporate-fair:hover {
                background-color: rgba(255, 215, 0, 0.5);
                box-shadow: 0 0 20px 8px rgba(255, 215, 0, 0.6);
            }

            .hover-area-handicraft {
                position: absolute;
                display: block;
                cursor: pointer;
                z-index: 10;
            }
        }
</style>

<body>
    <header>
        <!Doctype html>
  <html lang="en">
    <meta http-equiv="Cache-control" content="public">
	  <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="description" content="Bengal Business Council: Empowering businesses in Bengal with industry insights, trading opportunities, and economic growth strategies. Join the leading trade organization for entrepreneurs, companies, and start-ups in Bengal.">
    <meta name="keywords" content="Bengal Business Council, Business in Bengal, Bengal Industries, Bengal Companies, Start-ups in Bengal, Economic Growth, Trading Opportunities, Trade Centre, Business Membership, Bengal Entrepreneurship">
    <meta name="author" content="Bengal Business Council">
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
	  <title>Bengal Business Council : The voice of bengali businesses worldwide</title>

    <meta property="og:title" content="Bengal Business Council : The voice of bengali businesses worldwide">
    <meta property="og:description" content="Join Bengal Business Council to access industry insights, trading opportunities, and a network of businesses driving economic growth in Bengal.">
    <meta property="og:image" content="https://bengalbusinesscouncil.com/images/logo.webp">
    <meta property="og:url" content="https://bengalbusinesscouncil.com/">
    <meta property="og:type" content="website">
    <link rel="icon" href="/images/icon/favicon.ico" type="image/x-icon">

    <link href="css/styles.css" rel="stylesheet" type="text/css"/>
    
    <link href="https://fonts.googleapis.com/css2?family=Work+Sans:wght@100;300;400;500;600;700;800&amp;display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display+SC:wght@400;700;900&amp;display=swap" rel="stylesheet">
    <link href="pro.min.css" rel="stylesheet"> 

    <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.28/dist/sweetalert2.min.css" rel="stylesheet">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <style>
      /* for textarea height in ckeditor */
        .ck-editor__editable[role="textbox"] {
          /* editing area */
          min-width: 100% !important;
          max-width: 100% !important;
          min-height: 200px !important;
          max-height: 300px !important;
        }

        div:where(.swal2-container) button:where(.swal2-styled).swal2-confirm {
            border: 0;
            border-radius: .25em;
            background: initial;
            background-color: #337ab7;
            color: #fff;
            font-size: 1em
        }

        div:where(.swal2-container) button:where(.swal2-styled).swal2-confirm:focus {
            box-shadow: none;
        }

        @media (min-width: 1500px) {
          ul.sub-menu {
            background: #fff;
            opacity: 0;
            position: absolute;
            top: 100%;
            left: 85%;
            transform: scaleY(0);
            transform-origin: 0 0 0;
            transition: all 0.4s ease-in-out 0s;
            min-width: 150px;
            min-height: 250px;
            z-index: 99999 !important;
            visibility: hidden;
            -webkit-box-shadow: 0px 7px 7px 0px rgba(48, 51, 50, 0.09);
            -moz-box-shadow: 0px 7px 7px 0px rgba(48, 51, 50, 0.09);
            box-shadow: 0px 7px 7px 0px rgba(48, 51, 50, 0.09);
            text-align: left !important;
            padding: 0 5px !important;
            margin: 0 0 0 0 !important;
            line-height: 27px !important;
            margin-top: 1rem;
          }


          nav.menu ul li:hover .sub-menu {
            opacity: 1;
            transform: scaleY(1);
            transform-origin: 0 0 0;
            visibility: visible;
            transition: all 0.4s ease-in-out 0s;
            margin-left: -100px;
          }

          .sub-menu li:last-child {
            /* margin: 0 !important; */
            /* padding: 6px 10px !important; */
            /* margin-top:-5px !important; */
            
          }

          .sub-menu li a {
            padding: 0 !important;
            color: #555;
            clear: both;
            width: 100%;
          }

          ul li a {
            margin-left: 10px;
          }

          .submenu li a:hover {
            padding-left: 30px;
          }

          ul li a:hover {
            color: #D83030;
          }
          .submenu li a:hover{
            color: #D83030;
          }
          .submenuli{
            border: 2px solid #eee;  
            min-width: 180px;
            max-width: 200px;
            margin: 3px 0 !important;
          }
    

          .submenuli:hover{
            background: #D83030;
            transition: 0.5s ease-in-out;
          }
          .submenuli:hover a{
            color: #fff !important;
          }
        }

        @media (max-width: 1500px) {
          ul.sub-menu {
            background: #fff;
            opacity: 0;
            position: absolute;
            top: 100%;
            left: 85%;
            transform: scaleY(0);
            transform-origin: 0 0 0;
            transition: all 0.4s ease-in-out 0s;
            min-width: 150px;
            min-height: 250px;
            z-index: 99999 !important;
            visibility: hidden;
            -webkit-box-shadow: 0px 7px 7px 0px rgba(48, 51, 50, 0.09);
            -moz-box-shadow: 0px 7px 7px 0px rgba(48, 51, 50, 0.09);
            box-shadow: 0px 7px 7px 0px rgba(48, 51, 50, 0.09);
            text-align: left !important;
            padding: 0 5px !important;
            margin: 0 0 0 0 !important;
            line-height: 27px !important;
            margin-top: 1rem;
          }


          nav.menu ul li:hover .sub-menu {
            opacity: 1;
            transform: scaleY(1);
            transform-origin: 0 0 0;
            visibility: visible;
            transition: all 0.4s ease-in-out 0s;
            margin-left: -100px;
          }

          .sub-menu li:last-child {
            /* margin: 0 !important; */
            /* padding: 6px 10px !important; */
            /* margin-top:-5px !important; */
            
          }

          .sub-menu li a {
            padding: 0 !important;
            color: #555;
            clear: both;
            width: 100%;
          }

          ul li a {
            margin-left: 10px;
          }

          .submenu li a:hover {
            padding-left: 30px;
          }

          ul li a:hover {
            color: #D83030;
          }
          .submenu li a:hover{
            color: #D83030;
          }
          .submenuli{
            border: 2px solid #eee;  
            min-width: 180px;
            max-width: 200px;
            margin: 3px 0 !important;
          }
    

          .submenuli:hover{
            background: #D83030;
            transition: 0.5s ease-in-out;
          }
          .submenuli:hover a{
            color: #fff !important;
          }

          
        }

        @media (max-width: 991px) {
          ul.sub-menu {
              background: #fff;
              opacity: 0;
              position: absolute;
              top: 100% !important;
              left: 5% !important;
              transform: scaleY(0);
              transform-origin: 0 0 0;
              transition: all 0.4s ease-in-out 0s;
              min-width: 150px !important;
              min-height: 250px !important;
              z-index: 99999 !important;
              visibility: hidden;
              -webkit-box-shadow: 0px 7px 7px 0px rgba(48, 51, 50, 0.09);
              -moz-box-shadow: 0px 7px 7px 0px rgba(48, 51, 50, 0.09);
              box-shadow: 0px 7px 7px 0px rgba(48, 51, 50, 0.09);
              text-align: left !important;
              padding: 0 5% !important;
              margin: 0 !important;
              line-height: 20px !important;
              margin-top: 1rem;
          }
          nav.menu ul li ul{
            background: #131313 !important;
            width: 30% !important;
          }
          nav.menu ul li ul li:last-child{
            border-bottom: 1px solid #c7c7c7;
          }

          .apply_for_membership span a {
            margin-top: 13px !important;
          }
        }

        @media (min-width: 992px) {
          .apply_for_membership {
            margin-top: 18px !important;
          }
          .angel_network {
            margin-top: 18px !important;
          }
        }

        @media (max-width:772px) {
          ul.sub-menu {
              background: #fff;
              opacity: 0;
              position: absolute;
              top: 100% !important;
              left: 5% !important;
              transform: scaleY(0);
              transform-origin: 0 0 0;
              transition: all 0.4s ease-in-out 0s;
              min-width: 150px;
              min-height: 250px;
              z-index: 99999 !important;
              visibility: hidden;
              -webkit-box-shadow: 0px 7px 7px 0px rgba(48, 51, 50, 0.09);
              -moz-box-shadow: 0px 7px 7px 0px rgba(48, 51, 50, 0.09);
              box-shadow: 0px 7px 7px 0px rgba(48, 51, 50, 0.09);
              text-align: left !important;
              padding: 0 5% !important;
              margin: 0 !important;
              line-height: 20px !important;
          }
          nav.menu ul li ul{
            background: #131313 !important;
            width: 35% !important;
          }
          nav.menu ul li ul li:last-child{
            border-bottom: 1px solid #c7c7c7;
          }
        }

        @media (max-width: 650px) {
          ul.sub-menu {
              background: #fff;
              opacity: 0;
              position: absolute;
              top: 100% !important;
              left: 5% !important;
              transform: scaleY(0);
              transform-origin: 0 0 0;
              transition: all 0.4s ease-in-out 0s;
              min-width: 150px;
              min-height: 250px;
              z-index: 99999 !important;
              visibility: hidden;
              -webkit-box-shadow: 0px 7px 7px 0px rgba(48, 51, 50, 0.09);
              -moz-box-shadow: 0px 7px 7px 0px rgba(48, 51, 50, 0.09);
              box-shadow: 0px 7px 7px 0px rgba(48, 51, 50, 0.09);
              text-align: left !important;
              padding: 0 5% !important;
              margin: 0 !important;
              line-height: 15px !important;
          }
          nav.menu ul li ul{
            background: #131313 !important;
            width: 40% !important;
          }
          nav.menu ul li ul li:last-child{
            border-bottom: 1px solid #c7c7c7;
          }
        }

        @media (max-width: 560px) {
          ul.sub-menu {
              background: #fff;
              opacity: 0;
              position: absolute;
              top: 100% !important;
              left: 5% !important;
              transform: scaleY(0);
              transform-origin: 0 0 0;
              transition: all 0.4s ease-in-out 0s;
              min-width: 150px;
              min-height: 250px;
              z-index: 99999 !important;
              visibility: hidden;
              -webkit-box-shadow: 0px 7px 7px 0px rgba(48, 51, 50, 0.09);
              -moz-box-shadow: 0px 7px 7px 0px rgba(48, 51, 50, 0.09);
              box-shadow: 0px 7px 7px 0px rgba(48, 51, 50, 0.09);
              text-align: left !important;
              padding: 0 5% !important;
              margin: 0 !important;
              line-height: 15px !important;
          }
          nav.menu ul li ul{
            background: #131313 !important;
            width: 60% !important;
          }
          nav.menu ul li ul li:last-child{
            border-bottom: 1px solid #c7c7c7;
          }
        }

        p,a,li,a {
          font-size: 15px;
          font-family: "Work Sans", sans-serif !important;
        }
        .banglar-nobojagoron .fa-bell {
          color: red; /* make the bell icon red */
          font-size: 18px; /* adjust icon size if needed */
          vertical-align: middle;
          margin-top:73px !important;
          margin-left: -24px !important;
        }

        /* slower blinking animation */
        .blinking-icon {
          animation: blink 2s infinite; /* slower blink */
        }

        /* keyframes for blinking effect */
        @keyframes blink {
          0%, 50%, 100% {
            opacity: 1;
          }
          25%, 75% {
            opacity: 0;
          }
        }

        /* optional: make it look neat in navbar or list */
        li .banglar-nobojagoron {
          display: inline-block;
          padding: 5px 10px;
          text-decoration: none;
        }

    </style>

<script src="https://cdn.ckeditor.com/ckeditor5/39.0.2/classic/ckeditor.js"></script>

    <body>
		  <header>
        <nav class="menu" >
          <div class="menuBorder">
            <input type="checkbox" id="check">
            <label for="check" class="checkbtn"><i class="fas fa-bars"></i></label>
            <label class="logo"><a href="index"><img class="img-responsive full_width_img" src="images/logo.webp" alt="" width="74" height="65"></a></label>

            <ul class="menu-toggle" >
             <!-- <li><a href="index">Home</a></li> -->
              <li><a href="about">ABOUT US</a></li>
              <li><a href="newsletter">AALORON</a></li>
              <!-- <li><a href="banglar-nobojagoron">Nobojagoron</a></li> -->
              <li><a href="members">MEMBERS</a></li>
              <li><a href="gallery">GALLERY</a></li>
              <li><a href="event-calender">EVENT CALENDER</a></li>
              <li><a href="contact">CONTACT US</a></li>
              
                                  <li><a href="login">LOGIN</a></li>
                    <!-- <li style="margin-top: 18px;"><span class="council_btn"><a href="event-registration"> REGISTER FOR EVENTS</a></span></li> -->
                    <li class="apply_for_membership" style=""><span class="council_btn"><a href="registration"> APPLY FOR MEMBERSHIP</a></span></li>
                    <li class="angel_network" style=""><span class="council_btn"><a href="angel-network"> Angel Network</a></span></li>
                    <!-- <span title="Banglar Nobojagoran 4.0">
                      <a href="banglar-nobojagoron" class="banglar-nobojagoron">
                          <i class="fa fa-bell blinking-icon" aria-hidden="true"></i>
                      </a>
                    </span> -->
                              </ul>
          </div>
        </nav>
      </header>



    </header>

    <input type="hidden" id="hd_page_name_id" name="hd_page_name_id" value="10">

    <!-- ================= Main Body Start ================ -->
        
    <div class="container-wrapper">
        <div class="container-img">
            <!-- <img src="images/gangahridoi/gangahridoi_map.jpg" alt="Seat Map"> -->
            <img src="images/gangahridoi/gangahridoi-map-new.jpg" alt="Seat Map">
            <a class="link-area trade_fair" title="Trade Fair Zone" onclick="return handleStallClick('trade-fair-hangar.php','trade-fair-hangar')"></a>

            <!-- Custom-shaped hoverable area -->
            <a class="hover-area food-fair" title="Food Fair" onclick="return handleStallClick('food-fair-zone.php','food-fair-zone')"></a>
            <a class="hover-area-corporate corporate-fair" title="Corporate Fair" onclick="return handleStallClick('corporate-fair-zone.php','corporate-fair-zone')"></a>
            <a class="hover-area-handicraft handicraft-fair" title="Handicraft Fair" onclick="return handleStallClick('handicraft-fair-zone.php','handicraft-fair-zone')"></a>
        </div>
    </div>

    	<!-- Modal -->
	 <style>
		div label
		{
			font-weight: 400;
		}
	 </style>
	 

	


	<footer>
		<div class="fotr_main">
			<div class="container">
				<div class="row">
					<div class="col-sm-12 col-md-2 col-lg-2 col-12">
						<div class="ftrcel-1">
							<a class="ftr_logo" href="index">
								<img class="img-responsive lazy full_width_img" data-src="images/ftr_logo.jpg" alt="" width="100%" height="25">
							</a>
						</div>
					</div>
					<div class="col-sm-12 col-md-7 col-lg-7 col-12">
						<div class="ftrcel-2 lnktop" style="height: 450px;">
							<h5 style="border-bottom: 1px solid #cacaca; width: 90%;">Useful links</h5>
							<ul>
								<li><a href="index" style="font-size: 14px !important">HOME</a></li>
								<li><a href="about" style="font-size: 14px !important">ABOUT US</a></li>
								<li><a href="members" style="font-size: 14px !important">MEMBERS</a></li>
								<li><a href="gallery" style="font-size: 14px !important">GALLERY</a></li>
								<li><a href="event-calender" style="font-size: 14px !important">EVENT CALENDER</a></li>
								<li><a href="newsletter" style="font-size: 14px !important">AALORON</a></li>
								<li><a href="mou" style="font-size: 14px !important">MoU</a></li>
								<li><a href="contact" style="font-size: 14px !important">CONTACT US</a></li>
								<li><a href="terms-of-service" style="font-size: 14px !important">TERMS OF SERVICE</a></li>
								<li><a href="privacy-statement" style="font-size: 14px !important">PRIVACY STATEMENT</a></li>
								<li><a href="refund-policy" style="font-size: 14px !important">REFUND POLICY</a></li>
							</ul>

							<ol>
								<!-- <li><a href="images/TERMS%20OF%20SERVICE.pdf" target="_blank" style="font-size: 14px !important">Terms of Service</a></li> -->
																		<div>
										<span class="council_btn2_1" style="display:block;">
										<a href="login" style="font-size: 14px !important; color: #fff; background: #D83030; width: 100%; max-width: 100px; font-weight: 400; line-height: 40px; border-radius: 4px; height: 40px; padding: 10px !important;">LOGIN</a> <br>
										<a href="registration" style="font-size: 14px !important; color: #fff; background: #D83030; width: 100%; max-width: 100px; font-weight: 400; line-height: 40px; border-radius: 4px; height: 40px; padding: 10px !important;"> APPLY FOR MEMBERSHIP</a> <br>
										<a href="angel-network" style="font-size: 14px !important; color: #fff; background: #D83030; width: 100%; max-width: 100px; font-weight: 400; line-height: 40px; border-radius: 4px; height: 40px; padding: 10px !important;"> ANGEL NETWORK</a> <br>
										</span>
										</div>
																	<!-- <div>
									<span class="council_btn2_1" style="display: block;">
										<a href="book-my-ads" style="font-size: 14px !important; color: #fff; background: #D83030; width: 100%; font-weight: 400; line-height: 40px; border-radius: 4px; height: 40px; padding: 10px !important;"> BOOK MY ADS</a>
									</span>
								</div> -->
							</ol>
						</div>
					</div>
					<div class="col-sm-12 col-md-3 col-lg-3 col-12">
						<div class="ftrcel-3">
							<h5 style="border-bottom: 1px solid #cacaca;">Contact</h5>
							<ul>
							<li style="font-size: 13px !important">
								<span class="ficn fmap_icn">
								<img class="lazy" data-src="images/h-map-icn.png" alt="" style="width:13px;">
								</span> <b style="font-size: 14px;">Registered Address:</b> <br>213C, Mahatma Gandhi Road, Kolkata 700007.
							</li>
							<li style="font-size: 13px !important;">
								<span class="ficn fmap_icn">
								<img class="lazy" data-src="images/h-map-icn.png" alt="" style="width:13px;">
								</span> <b style="font-size: 14px;">Office of the Founder & General Secretary:</b> <br>47/1 Mahatma Gandhi Road, Kolkata 700009.
							</li>
							<li style="font-size: 13px !important;">
								<span class="ficn">
								<img class="lazy" data-src="images/h-call-icn.png" alt="" style="width:13px;">
								</span> <b style="font-size: 14px;">Contact</b> <br> &nbsp;&nbsp;&nbsp;&nbsp; +91 8274948310
							</li>
							<li style="font-size: 13px !important; margin-top: -15px;">
								<span class="ficn">
								<img class="lazy" data-src="images/h-mail-icn.png" alt="" style="width:13px;">
								</span>
								<b style="font-size: 14px;">Email</b> <br> &nbsp;&nbsp;&nbsp;&nbsp; admin@bengalbusinesscouncil.com <br> &nbsp;&nbsp;&nbsp;&nbsp; gm@bengalbusinesscouncil.com
							</li>
							</ul>

							<div class="socalbx">
							<ul>
								<li>
								<a href="#" target="_blank">
									<i class="fab fa-facebook-f"></i>
								</a>
								</li>
								<li>
								<a href="#" target="_blank">
									<i class="fab fa-linkedin-in"></i>
								</a>
								</li>
							</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="fotr_botm">
			<div class="container">
				<div class="row">
					<div class="col-xs-12 col-md-12">
						<ul class="cpyrght">
							<li style="font-size: 13px !important">Copyright 2023 <span>©Bengal business council</span></li>
							<li style="font-size: 13px !important">All rights reserved </li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</footer>

	<div class="modal fade" id="page_popup" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content" id="modal-content">
                <!-- <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                    <h5 class="modal-title" id="exampleModalLabel">Nobojagoron 3.0 Early Bird offer</h5>
                </div>
                <div class="modal-body" id="modal-body"></div> -->
            </div>
        </div>
    </div>




	
	<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.28/dist/sweetalert2.all.min.js"></script>

	<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Work+Sans:wght@100;300;400;500;600;700;800&amp;display=swap" media="print" onload="this.media='all'" />
	<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Playfair+Display+SC:wght@400;700;900&amp;display=swap" media="print" onload="this.media='all'" />
	<noscript>
		<link href="https://fonts.googleapis.com/css2?family=Work+Sans:wght@100;300;400;500;600;700;800&amp;display=swap" rel="stylesheet" type="text/css" />
	</noscript>

	<noscript>
		<link href="https://fonts.googleapis.com/css2?family=Playfair+Display+SC:wght@400;700;900&amp;display=swap" rel="stylesheet" type="text/css" />
	</noscript>
					<link rel="stylesheet" href="css/merge.css">
			
	
	<script src="js/jquery-1.9.1.min.js"></script>
	<script src="js/merge.js"></script>
	<script src="js/owl.carousel.min.js"></script>

	<script>
		get_page_popup_by_page_name_id();

		function get_page_popup_by_page_name_id() 
		{
			var page_name_id = $("#hd_page_name_id").val().trim();
			var mode = "get_page_popup_by_page_name_id";

			$.post('footer-ajax.php', {
				"mode": mode,
				"page_name_id": page_name_id
			}, function(data) {
				// alert(data);
				// console.log(data);

				if (data.trim() !== "") 
				{
					document.getElementById("modal-content").innerHTML = data;

					setTimeout(() => {
						$('#page_popup').modal('show').css('display', 'block');
					}, 500);
				}
				else 
				{
					$('#page_popup').modal('hide');
					$('#modal-content').empty();
				}
			});
		}

		
		function validate_text_field(id, error_id, message) 
		{
			value = $('#' + id).val().trim();
			// alert("hello");
			if (value == '') {
				$('#' + error_id).html(message);

				$('#' + id).focus();

				$('#' + id).css('borderColor', 'red');
				$('#Submit').attr('disabled', true);
			} else {
				$('#' + error_id).html('');
				$('#' + id).css('borderColor', '#d2d6de');
				$('#Submit').attr('disabled', false);
			}
		}

		function validate_dropdown(id, error_id, message) 
        {
            value = $('#' + id).val().trim();
            if (value == 0) 
			{
                $('#' + error_id).html(message).css('color', 'red');
                $('#' + id).focus();
                $('#' + id).css('borderColor', 'red');
                $('#btn_book_stall').attr('disabled', true);
                // $('#Submit').attr('disabled', true);
                return false;
            } 
			else 
			{
                $('#' + error_id).html('');
                $('#' + id).css('borderColor', '#d2d6de');
                $('#btn_book_stall').attr('disabled', false);
                // $('#Submit').attr('disabled', false);
                return true;
            }
        }

		function validate_text_box(id, error_id, message) 
		{
			value = $('#' + id).val().trim();
			// alert("hello");
			if (value == '') {
				$('#' + error_id).html(message);

				$('#' + id).focus();

				$('#' + id).css('borderColor', 'red');
				$('#btn_book_stall').attr('disabled', true);
			} else {
				$('#' + error_id).html('');
				$('#' + id).css('borderColor', '#d2d6de');
				$('#btn_book_stall').attr('disabled', false);
			}
		}

		function isNumberKey(evt) 
		{
			var charCode = (evt.which) ? evt.which : event.keyCode

			if (charCode > 31 && (charCode < 48 || charCode > 57) && charCode != 46) {
				return false;
			} else {
				return true;
			}
		}

		function save_t_zone_stall_booking_master()
		{		
			var members_id = $('#hd_members_id').val().trim();

			var user_name = $('#txt_user_name').val().trim();
			if (user_name == "") 
			{
				$("#error_user_name").html("Name required !!");
				document.getElementById('txt_user_name').focus();

				$('#txt_user_name').css('borderColor', 'red');
				$('#btn_book_stall').attr('disabled', true);
				return false;
			}

			var user_company = $('#txt_user_company').val().trim();
			if (user_company == "") 
			{
				$("#error_user_company").html("Company required !!");
				document.getElementById('txt_user_company').focus();

				$('#txt_user_company').css('borderColor', 'red');
				$('#btn_book_stall').attr('disabled', true);
				return false;
			}

			var user_mobile = $('#txt_user_mobile').val().trim();
			if (user_mobile == "") 
			{
				$("#error_user_mobile").html("Mobile required !!");
				document.getElementById('txt_user_mobile').focus();

				$('#txt_user_mobile').css('borderColor', 'red');
				$('#btn_book_stall').attr('disabled', true);
				return false;
			}

			var user_email = $('#txt_user_email').val().trim();
			if (user_email == "") 
			{
				$("#error_user_email").html("Email required !!");
				document.getElementById('txt_user_email').focus();

				$('#txt_user_email').css('borderColor', 'red');
				$('#btn_book_stall').attr('disabled', true);
				return false;
			}

			var user_gst = $('#txt_user_gst').val().trim();
			if (user_gst == "") 
			{
				$("#error_user_gst").html("GST required !!");
				document.getElementById('txt_user_gst').focus();

				$('#txt_user_gst').css('borderColor', 'red');
				$('#btn_book_stall').attr('disabled', true);
				return false;
			}

			var user_address_1 = $('#txt_user_address_1').val().trim();
			if (user_address_1 == "") 
			{
				$("#error_user_address_1").html("Address required !!");
				document.getElementById('txt_user_address_1').focus();

				$('#txt_user_address_1').css('borderColor', 'red');
				$('#btn_book_stall').attr('disabled', true);
				return false;
			}

			var user_address_2 = $('#txt_user_address_2').val().trim();
			if (user_address_2 == "") 
			{
				$("#error_user_address_2").html("Address 2 required !!");
				document.getElementById('txt_user_address_2').focus();

				$('#txt_user_address_2').css('borderColor', 'red');
				$('#btn_book_stall').attr('disabled', true);
				return false;
			}

			var user_state_id = $('#ddl_state_id').val().trim();
			var user_state = $('#ddl_state_id :selected').text().trim();
			// alert("user_state:"+user_state);
			if (user_state_id == 0) 
			{
				$("#error_user_state").html("Select State !!");
				document.getElementById('ddl_state_id').focus();

				$('#ddl_state_id').css('borderColor', 'red');
				$('#btn_book_stall').attr('disabled', true);
				return false;
			}

			var user_city_id = $('#ddl_city_id').val().trim();
			var user_city = $('#ddl_city_id :selected').text().trim();
			// alert("user_city:"+user_city);
			if (user_city_id == 0) 
			{
				$("#error_user_city").html("Select City !!");
				document.getElementById('ddl_city_id').focus();

				$('#ddl_city_id').css('borderColor', 'red');
				$('#btn_book_stall').attr('disabled', true);
				return false;
			}

			var user_zip = $('#txt_user_zip').val().trim();
			if (user_zip == "") 
			{
				$("#error_user_zip").html("Zip required !!");
				document.getElementById('txt_user_zip').focus();

				$('#txt_user_zip').css('borderColor', 'red');
				$('#btn_book_stall').attr('disabled', true);
				return false;
			}

			$('#btn_book_stall').html(`Booking <i class="fa fa-spinner fa-spin" style="font-size:18px"></i>`);

			var total_net_amount = $('#hd_total_net_amount').val().trim();
			
			var mode = "save_t_zone_stall_booking_master";
			$.post('./stall_book_ajax.php',
			{
				"mode":mode,
				"members_id":members_id,
				"user_name":user_name,
				"user_company":user_company,
				"user_mobile":user_mobile,
				"user_email":user_email,
				"user_gst":user_gst,
				"user_address_1":user_address_1,
				"user_address_2":user_address_2,
				"user_city":user_city,
				"user_state":user_state,
				"user_zip":user_zip,
				"total_net_amount":total_net_amount
			},
			function(data)
			{
				// alert(data);
				// console.log(data);
				if(data.trim()>0)
				{
					save_t_zone_stall_booking_details(data.trim());
					// save_stall_booking_payment_details(data.trim());
					Swal.fire({
						position: 'top-center',
						icon: 'success',
						title: 'Stall Details Save Successfully.!!',
						text:"Our team will reach you soon.",
						showConfirmButton: false,
						timer: 1500
					})
					setTimeout(() => {
						window.location.reload();
					}, 3000);
				}
			})
		}

		

		function save_t_zone_stall_booking_details(zone_stall_booking_master_id)
		{
			var temp_stall_cart_id=0;
			var zone_stall_id=0;
			var ip_address=0;
			var zone_rate_id=0;
			var stall_side_id=0;
			var rate_per_stall=0;
			var gst_percentage=0;
			var net_amount=0;

			var icount = $('#txt_stall_counter').val().trim();

			for(i=1;i<icount;i++)
			{
				temp_stall_cart_id = temp_stall_cart_id+'~'+$('#txt_temp_stall_cart_id_'+i).val().trim();
				zone_stall_id = zone_stall_id+'~'+$('#txt_zone_stall_id_'+i).val().trim();
				ip_address = ip_address+'~'+$('#txt_ip_address_'+i).val().trim();
				zone_rate_id = zone_rate_id+'~'+$('#txt_zone_rate_id_'+i).val().trim();
				stall_side_id = stall_side_id+'~'+$('#txt_stall_side_id_'+i).val().trim();
				rate_per_stall = rate_per_stall+'~'+$('#txt_rate_per_stall_'+i).val().trim();
				gst_percentage = gst_percentage+'~'+$('#txt_gst_percentage_'+i).val().trim();
				net_amount = net_amount+'~'+$('#txt_net_amount_'+i).val().trim();
			}

			let mode = "save_t_zone_stall_booking_details";
			$.post('./stall_book_ajax.php',
			{
				"mode":mode,
				"zone_stall_booking_master_id":zone_stall_booking_master_id,
				"temp_stall_cart_id":temp_stall_cart_id,
				"zone_stall_id":zone_stall_id,
				"ip_address":ip_address,
				"zone_rate_id":zone_rate_id,
				"stall_side_id":stall_side_id,
				"rate_per_stall":rate_per_stall,
				"gst_percentage":gst_percentage,
				"net_amount":net_amount
			},
			function(data)
			{
				// alert(data);
				// console.log(data);
			})
		}

		

		// this not required as per meeting 11-09-2024 said that collect payment manually
		function save_stall_booking_payment_details(zone_stall_booking_master_id)
		{
			let mode = "save_stall_booking_payment_details";

			var members_id = $('#hd_members_id').val().trim();
			var payable_amount = $('#hd_payable_amount').val().trim();
			var user_name = $('#txt_user_name').val().trim();
			var user_mobile = $('#txt_user_mobile').val().trim();
			var user_email = $('#txt_user_email').val().trim();
			var user_gst = $('#txt_user_gst').val().trim();
			var user_address_1 = $('#txt_user_address_1').val().trim();
			var user_address_2 = $('#txt_user_address_2').val().trim();
			var user_city = $('#txt_user_city').val().trim();
			var user_state = $('#txt_user_state').val().trim();
			var user_zip = $('#txt_user_zip').val().trim();

			$.post('./stall_book_ajax.php',
			{
				"mode":mode,
				"members_id":members_id,
				"payable_amount":payable_amount,
				"user_name":user_name,
				"user_mobile":user_mobile,
				"user_email":user_email,
				"user_gst":user_gst,
				"user_address_1":user_address_1,
				"user_address_2":user_address_2,
				"user_city":user_city,
				"user_state":user_state,
				"user_zip":user_zip,
				"zone_stall_booking_master_id":zone_stall_booking_master_id
			},
			function(data)
			{
				document.write(data);
			})
		}

		function get_city_by_state_id()
		{
			var state_id = $("#ddl_state_id").val().trim();

			var mode = "get_city_by_state_id";

			$.post("footer-ajax.php", {
				"mode":mode,
				"state_id":state_id
			}, function(data) {
				// alert(data);
				// console.log(data);
				document.getElementById("ddl_city_id").innerHTML = data;
			})
		}

		function get_newsletter_city_by_state_id()
		{
			var state_id = $("#ddl_newsletter_state_id").val().trim();

			var mode = "get_newsletter_city_by_state_id";

			$.post("footer-ajax.php", {
				"mode":mode,
				"state_id":state_id
			}, function(data) {
				// alert(data);
				// console.log(data);
				document.getElementById("ddl_newsletter_city_id").innerHTML = data;
			})
		}

	</script>
</body>




</body>
<script>
    function handleStallClick(page, page_name)
    {
        // alert("Aritra");
        // 🟡 First time — show the SweetAlert message
        Swal.fire({
            title: "Are you a registered member?",
            icon: "question",
            showCancelButton: true,
            confirmButtonText: "Yes",
            cancelButtonText: "No",
            reverseButtons: true
        }).then((result) => {
            // ✅ Mark as shown

            if (result.isConfirmed) {
                // Step 1: Redirect to login page
                // const currentUrl = window.location.href;
                const redirectUrl = `login.php?mode=stall_booking&page_name=${page_name}`;
                window.location.href = redirectUrl;
            } else {
                // Step 2: Redirect directly
                window.location.href = page;
            }
        });

        return false; // prevent link default navigation
    }
</script>
</html>